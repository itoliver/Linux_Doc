# Open Broadcaster Software
This is the repository for OBS, an open source live streaming / recording app for Windows.

**Development on OBS has mostly stopped.** All future work is being focused on a rewrite of OBS called OBS Multiplatform. OBS MP has an improved core, cross-platform Windows / Mac / Linux support and a better plugin API. Please visit https://github.com/jp9000/obs-studio for the OBS MP repository. Outside of simple and specific bug fixes, pull requests for this version of OBS are unlikely to receive review - we encourage you to spend your time developing for OBS MP instead.

Downloadable binaries for Windows can be found on our website, https://obsproject.com/
