
#define CURRENT_DATE "Build_2013/6/27"

#define PRODUCT_NAME "Intel� Media SDK"

#define FILE_VERSION 4,13,6,27

#define FILE_VERSION_STRING "4,13,6,27"

#define FILTER_NAME_PREFIX "Intel� Media SDK"

#define FILTER_NAME_SUFFIX ""

#define PRODUCT_COPYRIGHT "Copyright� 2003-2013 Intel Corporation"

#define PRODUCT_VERSION 4,0,760,0

#define PRODUCT_VERSION_STRING "4,0,760,0"
